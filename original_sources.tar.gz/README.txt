MJSulib and slap are both developed and maintained by
Author: spooferman@excite.com (Mike Spooner)

But the sites the sources was hosted before, all are dead links.
So the goal of this git repository is to conserve the source
for interested users that have such a label printer.

This tarball has the original sources i have downloaded some times 
before the servers are down.
