/* computed source version-related strings.
 * THIS FILE IS GENERATED AUTOMATICALLY - DO NOT EDIT
 */
#include "mjsu.h"
#include "mjsuimpl.h"
const CHAR * const mjsulibver = "@(#)mjsulib	3.3	17jun2012 MJS";
